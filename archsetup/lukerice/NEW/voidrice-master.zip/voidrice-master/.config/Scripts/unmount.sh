#!/bin/bash
sync
umount /mnt/* 2> /dev/null
rm -d /mnt/* 2> /dev/null
